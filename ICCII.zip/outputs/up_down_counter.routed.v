// IC Compiler II Version W-2024.09 Verilog Writer
// Generated on 4/5/2026 at 5:42:31
// Library Name: up_down_counter_LIB
// Block Name: up_down_counter
// User Label: 
// Write Command: write_verilog ./outputs/up_down_counter.routed.v
module up_down_counter ( Clock , rst , up_down , count ) ;
input  Clock ;
input  rst ;
input  up_down ;
output [3:0] count ;

DFFARX1_RVT \count_reg[0] ( .D ( copt_net_1 ) , .CLK ( Clock ) , 
    .RSTB ( n9 ) , .Q ( count[0] ) , .QN ( n15 ) ) ;
DFFARX1_RVT \count_reg[1] ( .D ( copt_net_6 ) , .CLK ( Clock ) , 
    .RSTB ( n9 ) , .Q ( count[1] ) , .QN ( n16 ) ) ;
DFFARX1_RVT \count_reg[2] ( .D ( copt_net_7 ) , .CLK ( Clock ) , 
    .RSTB ( n9 ) , .Q ( count[2] ) , .QN ( n17 ) ) ;
DFFARX1_RVT \count_reg[3] ( .D ( copt_net_5 ) , .CLK ( Clock ) , 
    .RSTB ( n9 ) , .Q ( count[3] ) ) ;
INVX0_RVT U16 ( .A ( rst ) , .Y ( n9 ) ) ;
AO22X1_RVT U17 ( .A1 ( count[1] ) , .A2 ( count[0] ) , .A3 ( n16 ) , 
    .A4 ( copt_net_1 ) , .Y ( n10 ) ) ;
HADDX1_RVT U18 ( .A0 ( up_down ) , .B0 ( n10 ) , .SO ( N14 ) ) ;
INVX0_RVT U19 ( .A ( up_down ) , .Y ( n12 ) ) ;
OA222X1_RVT U20 ( .A1 ( up_down ) , .A2 ( n16 ) , .A3 ( n12 ) , 
    .A4 ( count[0] ) , .A5 ( count[1] ) , .A6 ( copt_net_1 ) , .Y ( n11 ) ) ;
HADDX1_RVT U21 ( .A0 ( count[2] ) , .B0 ( n11 ) , .SO ( N15 ) ) ;
AO22X1_RVT U22 ( .A1 ( count[1] ) , .A2 ( count[0] ) , .A3 ( n16 ) , 
    .A4 ( n12 ) , .Y ( n13 ) ) ;
OA221X1_RVT U23 ( .A1 ( count[2] ) , .A2 ( copt_net_1 ) , .A3 ( n17 ) , 
    .A4 ( up_down ) , .A5 ( n13 ) , .Y ( n14 ) ) ;
HADDX1_RVT U24 ( .A0 ( count[3] ) , .B0 ( n14 ) , .SO ( N16 ) ) ;
DELLN2X2_RVT copt_h_inst_691 ( .A ( n15 ) , .Y ( copt_net_1 ) ) ;
DELLN1X2_RVT copt_h_inst_695 ( .A ( N16 ) , .Y ( copt_net_5 ) ) ;
DELLN1X2_RVT copt_h_inst_696 ( .A ( N14 ) , .Y ( copt_net_6 ) ) ;
DELLN1X2_RVT copt_h_inst_697 ( .A ( N15 ) , .Y ( copt_net_7 ) ) ;
endmodule


